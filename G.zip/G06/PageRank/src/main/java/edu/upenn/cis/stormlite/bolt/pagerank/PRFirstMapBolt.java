package edu.upenn.cis.stormlite.bolt.pagerank;

public class PRFirstMapBolt extends PRMapBolt{
	static {
		isFirstMapBolt = true;
	}
}
