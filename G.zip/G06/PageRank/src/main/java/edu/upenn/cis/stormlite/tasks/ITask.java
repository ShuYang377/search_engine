package edu.upenn.cis.stormlite.tasks;

public interface ITask extends Runnable {
	public String getStream();
}
