package edu.upenn.cis455.mapreduce;

public enum Workerstatus  {
    MAPPING, WAITING, REDUCING, IDLE
}
