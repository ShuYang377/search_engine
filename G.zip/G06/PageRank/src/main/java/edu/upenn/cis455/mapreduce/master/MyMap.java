package edu.upenn.cis455.mapreduce.master;

import java.util.*;

public class MyMap extends HashMap<String, HashSet<String>> {
	public MyMap() {
		super();
	}
}
