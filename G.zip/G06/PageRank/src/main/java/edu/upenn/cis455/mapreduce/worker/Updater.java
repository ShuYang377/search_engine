package edu.upenn.cis455.mapreduce.worker;

import java.io.IOException;

/*
 * update master periodically(every 10 seconds);
 */
public class Updater extends Thread  {
	private WorkerAdmin workerCenter;
	
	public Updater(WorkerAdmin workerCenter) {
		this.workerCenter = workerCenter;
	}
	
	@Override
	public void run() {
		while(true) {
			try {
				//update master periodically(every 10 seconds);
				sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			try {
				if(workerCenter.shouldShutDown()) {
					System.exit(0);
				}
				this.workerCenter.updateMaster();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}


	}
	

}
