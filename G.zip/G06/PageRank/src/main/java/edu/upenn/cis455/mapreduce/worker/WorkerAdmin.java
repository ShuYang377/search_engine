package edu.upenn.cis455.mapreduce.worker;

import edu.upenn.cis.stormlite.Config;
import edu.upenn.cis.stormlite.DistributedCluster;
import edu.upenn.cis.stormlite.TopologyContext;
import edu.upenn.cis.stormlite.distributed.WorkerJob;
import edu.upenn.cis455.mapreduce.Workerstatus;
import edu.upenn.cis455.mapreduce.master.MasterApp;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/*
 * To send update information to master, every workerServer has a WorkerAdmin
 */
public class WorkerAdmin {

   
    private static WorkerAdmin instance;
    
    public static String masterLocation = "http://127.0.0.1:8000"; // read from WorkerMain
    public static String workerStorage;  // read from WorkerMain
    public static String outputFileName =  "output.txt";
    public static String inputDir;       // read from status interface, under wokerStorage
    public static String outputDir;      // read from status interface, under wokerStorage
    public static String outputFilePath; // equals outputDir + outputFileName
    
    public static String dbStore =  "store";
    public static String reducePrefix =  "reduceMap_";
    public static String resPrefix =  "res_";
    
    HttpURLConnection conn;
    Updater updater;
    
    /*
     * when set to true, Updater will trigger a system.exit() to shutdown the workerServer.
     */
    public boolean shouldShutDown = false;
    
    /*
     * return a instance of workerAdmin
     */
    public static WorkerAdmin getInstance() {
        if (instance == null) {
            instance = new WorkerAdmin();
        }
        return instance;
    }

    static List<String> topologies = new ArrayList<>();
    static DistributedCluster cluster = new DistributedCluster();

	public static String urlIDSet = "urlIdSet";
    List<TopologyContext> contexts;
    
    // information for workerStatusInfo
    String jobName = "None";
    Integer portNum = 0; 
    Integer keysRead = 0, keysWritten = 0;
    Workerstatus status;

    private WorkerAdmin() {
        contexts = new ArrayList<>();
        
        status = Workerstatus.IDLE;
    }

    /*
     * add context
     */
    public void addContext(TopologyContext context) {
        synchronized (contexts) {
            contexts.add(context);
        }
    }

    /*
     * add topology
     */
    public void addTopology(String topoId) {
        synchronized (topologies) {
            topologies.add(topoId);
        }
    }
    
    /*
     * setInputDir
     */
    public void setInputDir(String inputDir) {
    	WorkerAdmin.inputDir = inputDir;
    }

    /*
     * return flag shouldShutDown
     */
    public boolean shouldShutDown() {
    	return this.shouldShutDown;
    }
    
    /*
     * submit topology to cluster
     */
    public TopologyContext submitTopologyToCluster(WorkerJob workerJob) throws ClassNotFoundException, MalformedURLException, IOException {
    	this.jobName = workerJob.getConfig().get("job");
    	updateMaster();
        return cluster.submitTopology((workerJob.getConfig().get("job")), workerJob.getConfig(),workerJob.getTopology());
    }

    /*
     * get cluster
     */
    public static DistributedCluster getCluster() { 
    	return cluster; 
    }
    
    /*
     * get contexts
     */
    public List<TopologyContext> getContexts() { 
    	return contexts; 
    }

    /*
     * Shut down the workerServer.
     */
    @SuppressWarnings("deprecation")
	public void shutDown() throws InterruptedException {
        synchronized(topologies) {
            for (String topo: topologies) {
                cluster.killTopology(topo);
            }
        }
        cluster.shutdown();
        conn.disconnect();
        
        System.out.println("[WorckerCenter]: Shutdowning worker on port: " + portNum);
        this.shouldShutDown = true;

    }

    /*
     *  for debugging, clean the workerServer data.
     */
	public void clean() {

		System.out.println("[WorkerCenter]: clened");
		keysRead = 0;
		keysWritten = 0;
		
		// clean db on disk
		File directory = new File(WorkerAdmin.workerStorage);
		String preFix =  "reduceMap_";
		for (File f : directory.listFiles()) {
		    if (f.getName().startsWith(preFix)) {
		    	System.out.println("[WorkerCenter]: f.getName()" + f.getName());
		    	deleteDir(f);
		    }
		}
		
		//topologies = new ArrayList<>();
	    cluster = new DistributedCluster();
	    contexts = new ArrayList<>();
		
	}
	
	/////////////////////////////////////////////////
	////////////    Update Mater         //////////// 
	
    public synchronized void updateMaster() throws MalformedURLException, IOException {
        StringBuilder sb = new StringBuilder();
        sb.append(masterLocation + "/workerstatus?");
        sb.append("port=" + String.valueOf(this.portNum));
        sb.append("&job=" + jobName );
        sb.append("&status=" + status.toString());
        sb.append("&keysRead=" + keysRead);
        sb.append("&keysWritten=" + keysWritten);
        
        sb.append("&runningTime=" + System.currentTimeMillis());
        URL url = new URL(sb.toString());

        
        conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.connect();
        printResponse(conn);
    }

    // update keys read
    public void updateKeysRead() {
        synchronized (keysRead) {
            keysRead++;
        }
        try {
        	System.out.println("[WorkerAdmin]: keysRead : " + keysRead);
            updateMaster();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
     
    // update keys written
    public void updateKeysWritten() {
        synchronized (keysWritten) {
            keysWritten++;
        }
        try {
            updateMaster();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // update worker status (idle, reducing, mapping, waiting)
    public void updateWorkerStatus(Workerstatus st) {
        if (st == status) { return; }
        synchronized (status) {
            this.status = st;
        }
        try {
            updateMaster();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // send result to master
    public void sendResToMater(String key, String value) throws MalformedURLException, IOException {
        StringBuilder sb = new StringBuilder();
        sb.append(masterLocation + "/addresult?");
        sb.append("port=" + portNum);
        sb.append("&key=" + key);
        sb.append("&result=" + value);
        URL url = new URL(sb.toString());
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestMethod("POST");
        conn.connect();
        printResponse(conn);
    }
    
    public int myPort() {
    	return this.portNum;
    }
    
    /*
     * update master server periodically.
     */
    public void updateMasterPeriodically() {
    	updater = new Updater(this);
    	updater.start();
    	
    } 
    
    /*
     * the first time to update master.
     */
    public void firstUpdate(int portNum) throws MalformedURLException, IOException {
        this.portNum = portNum;
        updateMaster();
    }
    
    /*
     * print response
     */
    public static void printResponse(HttpURLConnection httpURLConnection) throws IOException {
        StringBuilder builder = new StringBuilder();
        builder.append(httpURLConnection.getResponseCode())
                .append(" ")
                .append(httpURLConnection.getResponseMessage())
                .append("\n");

    }

    
    /*
     * delete a directory recursively.
     */
	void deleteDir(File file) {
	    File[] contents = file.listFiles();
	    if (contents != null) {
	        for (File f : contents) {
	            deleteDir(f);
	        }
	    }
	    file.delete();
	}
	
	
	/*
	 * config storage infomation for worker node.
	 */
	public void addDirInfo(Config config) throws IOException {
		WorkerAdmin.inputDir = WorkerAdmin.workerStorage + "/"+ config.get("inputDir");
        if(!Files.exists(Paths.get(WorkerAdmin.inputDir))) {
    		Files.createDirectories(Paths.get(WorkerAdmin.inputDir));
    	}
		WorkerAdmin.outputDir = WorkerAdmin.workerStorage + "/" + config.get("outputDir");
        if(!Files.exists(Paths.get(WorkerAdmin.outputDir))) {
    		Files.createDirectories(Paths.get(WorkerAdmin.outputDir));
    	}
		//WorkerCenter.outputFilePath = WorkerCenter.workerStorage + "/"  + config.get("outputDir") + "/" +  WorkerCenter.outputFileName;
	}
}
