package edu.upenn.cis455.mapreduce.worker;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;


import edu.upenn.cis.stormlite.distributed.WorkerUtils;


/**
 * Simple listener for worker creation 
 * 
 * @author zives
 *
 */
public class WorkerMain {


	/**
	 * Simple launch for worker server.  Note that you may want to change / replace
	 * most of this.
	 * 
	 * @param args
	 * @throws MalformedURLException
	 */
	public static void main(String args[]) throws MalformedURLException {
       if (args.length != 3) {
          System.err.println("You need to provide: 1) the master's IP:port, 2) the path to the storage direcotry, and 3) the port number on which to listen for commands from the master.");
          System.exit(1);
        }
		
		String masterAddr = args[0];
		WorkerAdmin.masterLocation = "http://" +  masterAddr;
		
		String storageDir = args[1];
		WorkerAdmin.workerStorage = storageDir;
		
		int workerPort = Integer.valueOf(args[2]);
		
		System.out.println("Worker node startup, on port " + workerPort);
		new WorkerServer(workerPort);

	}


	public static void createWorker(Map<String, String> config) {
		if (!config.containsKey("workerList")) {
			throw new RuntimeException("Worker spout doesn't have list of worker IP addresses/ports");
		}

		if (!config.containsKey("workerIndex")) {
			throw new RuntimeException("Worker spout doesn't know its worker ID");
		} else {
			String[] addresses = WorkerUtils.getWorkerAddrs(config);
			System.out.println(config.get("workerIndex"));
			String myAddress = addresses[Integer.valueOf(config.get("workerIndex"))];
			URL url;
			try {
				url = new URL(myAddress);
				new WorkerServer(url.getPort());
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}
	}
}
