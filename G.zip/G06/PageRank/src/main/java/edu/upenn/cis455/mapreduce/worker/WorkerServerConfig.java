package edu.upenn.cis455.mapreduce.worker;

import edu.upenn.cis455.mapreduce.worker.routes.DefineJobhandler;
import edu.upenn.cis455.mapreduce.worker.routes.WorkerPageRank;
import edu.upenn.cis455.mapreduce.worker.routes.PushDataHandler;
import edu.upenn.cis455.mapreduce.worker.routes.RunJobHandler;

import java.io.IOException;
import java.net.MalformedURLException;

import static spark.Spark.port;
import static spark.Spark.post;

public class WorkerServerConfig {

    private int myPort;
    //private WorkerServer workerServer;
    public WorkerServerConfig(int port) {
        myPort = port;
        port(port);
        setUpRoutes();
        //this.workerServer = workerServer;
        firstUpdate();
    }

    private void setUpRoutes() {
        post("/definejob", new DefineJobhandler());
        post("/runjob", new RunJobHandler(WorkerAdmin.getCluster()));
        post("/pushdata/:stream", new PushDataHandler());
        post("/shutdown", (req, res)->{
			WorkerAdmin.getInstance().shutDown();
        	return "Shuting down workerServer on port: " + this.myPort;
        });
        
        post("/pageRanks", new WorkerPageRank());

        WorkerAdmin.getInstance().updateMasterPeriodically();
    }



	public void firstUpdate() {
        try {
            WorkerAdmin.getInstance().firstUpdate(myPort);
        } catch (MalformedURLException e) {
            System.err.println("Failed To Notify Master Due to MalformedURLException");
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Failed To Notify Master Due to IOException");
        }
    }



}
