package edu.upenn.cis455.mapreduce.worker.routes;

import com.fasterxml.jackson.databind.ObjectMapper;

import edu.upenn.cis.stormlite.Config;
import edu.upenn.cis.stormlite.TopologyContext;
import edu.upenn.cis.stormlite.distributed.WorkerJob;
import edu.upenn.cis455.mapreduce.worker.WorkerAdmin;
import spark.Request;
import spark.Response;
import spark.Route;

import java.io.IOException;

/*
 * Handle POST /definejob
 */
public class DefineJobhandler implements Route {

    @Override
    public Object handle(Request req, Response res) {
        final ObjectMapper om = new ObjectMapper();
        om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
        WorkerJob workerJob;
        try {
        	System.out.println("req.body() = " + req.body().substring(0,100));
            workerJob = om.readValue(req.body(), WorkerJob.class);
            Config config = workerJob.getConfig();
            try {
                System.out.println("[DefineJob]: Processing job definition request '" + config.get("job") +
                        "' on machine " + config.get("workerIndex"));
                        
                TopologyContext context = WorkerAdmin.getInstance().submitTopologyToCluster(workerJob);
                WorkerAdmin.getInstance().addContext(context);
                WorkerAdmin.getInstance().addTopology(config.get("job"));
                WorkerAdmin.getInstance().addDirInfo(config);
                
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            return "Job launched";
        } catch (IOException e) {
            e.printStackTrace();
            // Internal server error
            res.status(500);
            return e.getMessage();
        }

    }
}
