package edu.upenn.cis455.mapreduce.worker.routes;

import spark.Request;
import spark.Response;
import spark.Route;

import edu.upenn.cis.stormlite.DistributedCluster;


/**
 * Handle POST /runjob
 */
public class RunJobHandler implements Route {

	DistributedCluster cluster;
	
	public RunJobHandler(DistributedCluster cluster) {
		this.cluster = cluster;
	}

	@Override
	public Object handle(Request request, Response response) throws Exception {
		System.out.println("POST /runjob");
		cluster.startTopology();
		return "Started Running Job on Workers";
	}

}
