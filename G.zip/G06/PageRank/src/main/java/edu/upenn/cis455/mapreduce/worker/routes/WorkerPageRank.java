package edu.upenn.cis455.mapreduce.worker.routes;


import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

import org.apache.commons.io.IOUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.upenn.cis.stormlite.Config;
import edu.upenn.cis.stormlite.bolt.pagerank.DBWrapper;
import edu.upenn.cis455.mapreduce.master.MyMap;

import edu.upenn.cis455.mapreduce.worker.WorkerAdmin;
import spark.Request;
import spark.Response;
import spark.Route;

/*
 * Worker: Handle POST /pageRanks from workerServer.
 */
public class WorkerPageRank implements Route {

	private Config hashToBoltId;
	private Map<String, DBWrapper>  hashToDB;
    public WorkerPageRank () {
    	

    }

    @Override
    public Object handle(Request req, Response res) {
    	
    	try {
			this.hashToBoltId = this.requestHashToBoltId();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	for (String hash: hashToBoltId.keySet()) {
    		String executorId = hashToBoltId.get(hash);
    		String path = WorkerAdmin.dbStore + "/" + WorkerAdmin.resPrefix + executorId;
    		DBWrapper db = new DBWrapper(path);
    		hashToDB.put(path, db);
    		System.out.println("[WorkerPageRank]: hashToDB = " + hashToDB);
    	}
    	
    	System.out.println("[WorkerPageRank]: POST /pageRanks");
    	final ObjectMapper om = new ObjectMapper();
        om.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
        MyMap hashToQueryIds = null;
        try {
        	hashToQueryIds = om.readValue(req.body(), MyMap.class);
        	System.out.println("[WorkerPageRank]:hashToQueryIds = " + hashToQueryIds);
		} catch (JsonParseException e1) {
			e1.printStackTrace();
		} catch (JsonMappingException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
        
        // retrieve pageRanks for each worker bucket(executorId)
        Config pageRankMap = new Config();
        for (String hash: hashToQueryIds.keySet()) {
        	DBWrapper db = hashToDB.get(hash);
        	for (String queryId: hashToQueryIds.get(hash)) {
        		String rank = db.getRankById(queryId);
        		pageRankMap.put(queryId, rank);
        	}
        }
        
        
        // send back pageRanks to client.
        String resStr = "";
		try {
			resStr = om.writerWithDefaultPrettyPrinter().writeValueAsString(pageRankMap);
			System.out.println("[WorkerPageRank]: res =" + resStr);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return resStr;
    }
   
	public Config requestHashToBoltId() throws IOException {

        ObjectMapper mapper = new ObjectMapper();
        mapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
		StringBuilder sb = new StringBuilder();

		System.out.println(WorkerAdmin.masterLocation + "/hashToBoltId");
        sb.append(WorkerAdmin.masterLocation + "/hashToBoltId");
        URL url = new URL(sb.toString());

        // send request
        HttpURLConnection conn;
        conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        // read response
        InputStream in = conn.getInputStream();
        String encoding = conn.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String hashToBoltIdStr = IOUtils.toString(in, encoding);
        Config hashToBoltId = mapper.readValue(hashToBoltIdStr, Config.class);
        System.out.println("[WorkerPageRank]:  hashToBoltId = " + hashToBoltId);
        
        return hashToBoltId;
	}


}
