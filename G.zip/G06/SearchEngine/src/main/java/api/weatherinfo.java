package api;

public class weatherinfo {
	public String state;
    public String value;
    public String min;
    public String max;
    public String humidity;
    public String wind;
    public String time;
    public String icon;
    public String weather;
}
