package api;

public class yelpInfo {
	public String img;
	public String distance;
	public String rating;
	public String phone;
	public String location;
}
