package queryDataBase;

public class RequestPageRank {

}

