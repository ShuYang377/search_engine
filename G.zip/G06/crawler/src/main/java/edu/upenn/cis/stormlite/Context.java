package edu.upenn.cis.stormlite;

public interface Context {

  void write(String key, String value);
  
}
